/*
*****************************************************************************
                              Workshop - #1 (Part-1)
Full Name  : Aryan Khurana
Student ID#: 145282216
Email      : akhurana22@myseneca.ca
Section    : NJJ

Authenticity Declaration:
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
*****************************************************************************
*/
#include <stdio.h>

int main() 
{
    printf("Workshop 1 Part-1\n");
    printf("=================\n");
    printf("\n");
    printf("I'm displaying this using the 'printf' stdio\n");
    printf("(standard input output) library function!\n");
    printf("\n");
    printf("Dear teacher,\n");
    printf("\n");
    printf("  I promise I will work hard from this day onward.\n");
    printf("  I acknowledge that practice is extremely important,\n");
    printf("  so I will do all workshops, quizzes, and assignments.\n");
    printf("\n");
    printf("Sincerely,\n");
    printf("\n");
    printf("Aryan Khurana\n");
    printf("Student ID# 145282216\n");

    return 0;
}