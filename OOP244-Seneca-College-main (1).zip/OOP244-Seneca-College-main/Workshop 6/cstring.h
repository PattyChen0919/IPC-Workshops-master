
//==============================================
// Name           : Kabir Narula
// Email          : Knarula9@myseneca.ca
// Student ID     : 127962223
// Section        : NAA
// Date           : 04/07/2023(Tuesday)
//==============================================
//I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assignments.

#ifndef SDDS_CSTRING_H__
#define SDDS_CSTRING_H_
namespace sdds
{
	int strLen(const char* s);
	void strCpy(char* des, const char* src);
	void strCat(char* des, const char* src);
}
#endif // !SDDS_CSTRING_H_