# C++ Workshop Assignments Repository
Hey there! Welcome to my C++ Workshop Assignments repository! As a college student passionate about programming, I've created this public repository to share the C++ assignments I've been working on during my course. These assignments cover various aspects of C++ and are designed to help students like you improve your coding skills.

# Marks secured 

 Workshop 01: 10/10                                                                                                                                           
 Workshop 02: 10/10                                                                                                                                                   
 Workshop 03: 10/10                                                                                                                                       
 Workshop 04: 10/10                                                                                                                                                   
 Workshop 05: 10/10                                                                                                                                                  
 Workshop 06: 10/10                                                                                                                                                   
 Workshop 07: 10/10                                                                                                                                                   
 Workshop 08: 10/10                                                                                                                                                   
 Workshop 09: 10/10                                                                                                                                                   
 Worskhop 10: 10/10

Final Project:

Milestone 01: 10/10                                                                                                                                        
Milestone 02: 10/10                                                                                                                                        
Milestone 03: 10/10                                                                                                                                        
Milestone 04: 10/10                                                                                                                                        
Milestone 05: Pending...

# Personal Notes
Throughout this course, I have compiled comprehensive notes covering all the essential topics and concepts in C++. These notes serve as a valuable resource for understanding the fundamentals of the language, object-oriented programming, control statements, arrays, functions, file handling, and more. Additionally, I have included examples and practical exercises to reinforce the learning process. Whether you are a beginner or seeking to deepen your C++ knowledge, these notes will prove indispensable. You can access the course notes https://github.com/LeviAcker25/C--Plus-Plus-Notes. Feel free to use and share these resources, and I hope they aid you in your journey to becoming a proficient C++ developer. Happy learning!
# Disclaimer

The content provided in this repository is intended for educational and informational purposes only. The code, assignments, and project milestones shared here represent my personal work completed during my C Workshop course. While I encourage fellow students to use this repository as a source of inspiration and learning, I want to emphasize the importance of academic integrity and ethical conduct.

**Copying, reproducing, or submitting the code from this repository as your own for academic assignments is a violation of academic integrity**. It is essential to understand the concepts, principles, and coding techniques presented here and to apply them independently to your own work.

Using this repository as a reference is encouraged, but direct replication without genuine effort and comprehension not only compromises your learning experience but also undermines the principles of learning and growth that education is built upon. Proper attribution and acknowledgment are critical if you choose to integrate any concepts or ideas from this repository into your own projects or assignments.

By accessing and using the content in this repository, you acknowledge that you understand the implications of academic integrity https://www.senecacollege.ca/about/policies/academic-integrity-policy.html and that you will use this material responsibly to enhance your learning journey.

# Need Help?
If you encounter any issues or have questions related to the assignments or C++ programming in general, feel free to reach out to me. I'm more than willing to help you out! You can contact me through the following means:

Email: ackerlevi102@gmail.com                                                                                                                                     

